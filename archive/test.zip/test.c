#include <stdio.h>
#include "test.h"

//gcc test.c -o test
//x86_64-w64-mingw32-gcc -o test.exe test.c


int i,j,a,b;
BYTE b_1, b_2, b_3;
BYTE pos = 1;

void main ()
{
	while(1){
		switch(prog())
		{
			case 1:
				bit_value();
			break;
			case 12:
				bit_mask();
			break;
			case 2:
				pointer();
			break;
			case 21:
				pointer_double();
			break;
			case 22:
				pointer_with_funx();
			break;
			case 3:
				structure();
			break;
			case 100:
				printf("%%u - unsigned integer\n");
				printf("%%x - hexadecimal value\n");
				printf("%%p - void pointer\n");	
			break;
			case 0:
				return;
			break;
		}
	}
}

void structure()
{
	printf("________________________________\n");
	printf("Structure\n\n");
	
	printf("in header file\n");
	printf("typedef struct\n");
	printf("{\n");
	printf("	int 		one;\n");
	printf("	char	 	two[10];\n");
	printf("	BYTE 		flag1: 1;\n");
	printf("	BYTE 		flag2: 1;\n");
	printf("	BYTE 		others:6;\n");
	printf("}STRCT;\n");
	printf("extern STRCT str;\n");
	printf("\nin source file\n");
	
	STRCT str;
	str.one = 10;
	str.two[2] = *(char*)&str.one;
	str.flag1 = 1;
	str.others = 40;
	
	printf("STRCT str;\n");
	printf("str.one = 10;//%d\n",str.one);
	printf("str.two[2] = str.one;//%d\n",str.two[2]);
	printf("str.flag1 = 1;//%d\n",str.flag1);
	printf("str.others = 40;//%d\n",str.others);
	
	STRCT* str_ptr = &str;
	str_ptr->one = 11;
	printf("STRCT* str_ptr = &str;\n");
	printf("str_ptr->one = 11;\n");
	printf("str_ptr->one = %d;\n",str_ptr->one);
	
}


void f1(int* ptr)
{
	*ptr = *ptr + 20;
}

void f2(int* dst,int* src,int len)
{
	for(i = 0;i < len; i++) {*dst++ = *src++;}
}

void pointer_with_funx()
{
	printf("________________________________\n");
	printf("Pointers with funx:\n");
	a = 11;
	int* p = &a;
	f1(p); 
	printf("\n\na = 11;\nint* p = &a;\nf1(p);\n\nvoid f1(*int ptr)\n{\n	*ptr = *ptr + 20;\n	return 0;\n}\n");
	printf("a = %d\n",a);
	
	char c = 31;
	f1((int*)&c);
	printf("\n\nchar c = 31;\nf1((int*)c);\n\nvoid f1(*int ptr)\n{\n	*ptr = *ptr + 20;\n	return 0;\n}\n");
	printf("c = %d\n",c);
	
	int massive_1[16];
	int massive_2[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
	f2(massive_1, massive_2, 16);
	printf("\n\nint massive_1[16];\nint massive_2[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};\n");
	printf("f2(massive_1, massive_2, 16);\n\nvoid f2(int* dst,int* src,int len)");
	printf("\n{\n	for(i = 0;i < len; i++) {*dst++ = *src++;}\n	return 0;\n}\n");
	printf("massive_1 = {");
	for (i = 0; i < 16; i++) {printf("%d ",massive_1[i]);}
	printf("}\n");
	
	
}

void pointer_double()
{
	printf("________________________________\n");
	printf("Pointers double definition:\n");
	a = 0;
	int* p = &a;
	int** p2 = &p;
	printf("\n\na = 0;\nint* p = &a;\nint** p2 = &p;\n");
	printf("p = %p(address a), p2 = %p(address p)\n",p,p2);
	printf("*p = %d(value a), *p2 = %p(address a), **p2 = %d(value a)\n",*p,*p2,**p2);
	
	
	a = 10;
	printf("\n\na = 10;\n");
	printf("p = %p(address a), p2 = %p(address p)\n",p,p2);
	printf("*p = %d(value a), *p2 = %p(address a), **p2 = %d(value a)\n",*p,*p2,**p2);
	
	int******** p3;
	printf("\n\nint******** p3; - it`s possible\n");
	
}

void pointer()
{
	printf("________________________________\n");
	printf("Pointers definition:\n");
	int* p;
	a = 1;
	b = 2;
	p = &a;
	printf("int* p;\na = 1;\nb = 2;\np = &a;\n");
	printf("p = %p, *p = %d\n",p,*p);
	*p = *p + 2;
	printf("Pointers plus value:\n");
	printf("*p = *p + 2;\n");
	printf("a = %d, *p = %d\n",a,*p);
	printf("\n\nPointers with massive:\n");
	
	int c[] = {1,2,3,4,5,6,7,8};
	int* p2 = c;
	p = &c[0];
	printf("int c[] = {1,2,3,4,5,6,7,8};\np2 = c;\np = &c[0];\n");
	printf("p2 = %p, p = %p\n",p2,p);
	printf("*p2 = %d, *p = %d\n",*p2,*p);
	
	p = &c[4];
	*p = 10;
	printf("\n\np = &c[4];\n*p = 10;\n");
	printf("p2 = %p, p = %p\n",p2,p);
	printf("*p2 = %d, *p = %d\n",*p2,*p);
	p2 = p2 + 4;
	printf("\np2 = p2 + 4;\n");
	printf("p2 = %p, p = %p\n",p2,p);
	printf("*p2 = %d, *p = %d\n",*p2,*p);
	
	char* p3 = c;
	p2 = c;
	printf("\n\nchar* p3 = c;\np2 = c;\n");
	printf("p2 = %p, p30 = %p\n",p2,p3);
	printf("*p2 = %d, *p3 = %d\n",*p2,*p3);
	c[0] = 3967;
	printf("\n\nc[0] = 3967, 0000 1111 0111 1111;\n");
	printf("p2 = %p, p3 = %p\n",p2,p3);
	printf("*p2 = %d, *p3 = %d\n",*p2,*p3);
	printf("*p2(binary) = 0000 1111 0111 1111, *p3(binary) = 0111 1111\n");
	p3 = p3 + 1;
	p2 = p2 + 1;
	printf("\n\np3 = p3 + 1;\np2 = p2 + 1;\n");
	printf("p2 = %p, p3 = %p\n",p2,p3);
	printf("*p2 = %d(two element massive), *p3 = %d(0000 1111)\n",*p2,*p3);
	printf("0000 1111 - is two bit in c[0](first element massive\n");
}

void bit_mask()
{
	printf("________________________________\n");
	b_1 = 2;
	printf("\nread flag\nb_1 = %d, b_1 = 00000010\n",b_1);
	b_2 = 1;
	printf("b_2 = %d, b_2 = 00000001\n",b_2);
	b_3 = 0;
	printf("b_3 = %d, b_3 = 00000000\n",b_3);
	b_3 = give_flag(b_1, pos);
	printf("((b_1 >> b_2) & 0x01  =  b_3\n");
	printf("b_3 = %d, b_3 = 00000001\n\nset flag\n",b_3);
	
	b_3 = 4;
	printf("b_3 = %d,  b_3 = 00000100\n",b_3);
	set_flag(&b_1, b_3);
	printf("((b_1) | (0x01 << b_3))  =  b_1\n");
	printf("b_1 = %d, b_1 = 00010010\n",b_1);
	
	printf("\nclear flag\nb_1 = %d, b_1 = 00010010\n",b_1);
	clr_flag(&b_1, b_3);
	printf("b_1 = b_1 & (0xFF - (0x01 << b_3));\n");
	printf("b_1 = %d,  b_1 = 00000010\n",b_1);
}

void bit_value()
{
	printf("________________________________\n");
	a = 2;
	b = 4;
	printf("a(%d) >> 1 = %d\n",a,a>>1);
	printf("000010 >> 000001\n");
	printf("b(%d) >> 1 = %d\n",b,b>>1);
	printf("000100 >> 000010\n");
	
	printf("a(%d) << 1 = %d\n",a,a<<1);
	printf("000010 << 000100\n");
	printf("b(%d) << 1 = %d\n",b,b<<1);
	printf("000100 << 001000\n");
	
	a = 60;
	printf("\nNext (|, &):\na = 60, a = 00111100\n");
	b = 12;
	printf("b = 12, b = 00001100\n");
	printf("a(%d) | b(%d) = %d, 00111100\n",a,b,a|b);
	printf("a(%d) & b(%d) = %d, 00001100\n",a,b,a&b);
	a = 40;
	printf("\na = %d, a = 00101000\n",a);
	printf("b = %d, b = 00001100\n",b);
	printf("a(%d) | b(%d) = %d, 00101100\n",a,b,a|b);
	printf("a(%d) & b(%d) = %d, 00001000\n",a,b,a&b);

}

int prog()
{
	int fork;
	printf("________________________________\n");
	printf("\n0 - Exit.\n");
	printf("1 - Byte operations.\n");
	printf("12 - Byte mask operation.\n");
	printf("2 - Pointer.\n");
	printf("21 - Pointer: double pointer.\n");
	printf("22 - Pointer: with funx.\n");
	printf("3 - struct.\n");
	printf("100 - printf help.\n");
	printf("Programm N...\n");
	scanf("%d",&fork);
	return fork;
}

BYTE give_flag(BYTE byte, BYTE pos)
{
	BYTE rtn = ((byte >> pos) & 0x01);
	return rtn;
}

BYTE set_flag(BYTE *byte, BYTE pos)
{
	*byte = ((*byte) | (0x01 << pos));
	//printf("\n\npos = %d, byte = %d\n\n",*byte, pos);
	return 0;
}

BYTE clr_flag(BYTE *byte, BYTE pos)
{
	*byte = *byte & (0xFF - (0x01 << pos));
	//printf("\n\npos = %d, byte = %d\n\n",*byte, pos);
	return 0;
}











