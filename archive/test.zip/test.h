#ifndef TEST_H_
#define TEST_H_

typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef unsigned int   DWORD;

#include <string.h>
#include <stdlib.h>

typedef struct
{
	int 		one;
	char 		two[10];
	BYTE 		flag1: 1;
	BYTE 		flag2: 1;
	BYTE 		others:6;
}STRCT;

extern STRCT str;

void bit_value();
void bit_mask();
void pointer();
int prog();
void pointer_with_funx();
void pointer_double();
void structure();

BYTE give_flag(BYTE byte, BYTE pos);
BYTE set_flag(BYTE *byte, BYTE pos);
BYTE clr_flag(BYTE *byte, BYTE pos);

//%u - unsigned integer
//%x - hexadecimal value
//%p - void pointer

#endif /* TEST_H_ */
